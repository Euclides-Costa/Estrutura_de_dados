/*
4. Joaozinho quer calcular e mostrar a quantidade de litros de combustível gastos em uma
viagem, ao utilizar um automóvel que faz 12 KM/L. Para isso, ele gostaria que você o
auxiliasse através de um simples programa. Para efetuar o cálculo, deve-se fornecer o tempo
gasto na viagem (em horas) e a velocidade média durante a mesma (em km/h). Assim, podese obter distância percorrida e, em seguida, calcular quantos litros seriam necessários.
Mostre o valor com 3 casas decimais após o ponto.
*/

#include <stdio.h>
#include <math.h>

int main(void)
{
  int AUTONOMIA = 12;
  float distancia = 0;
  float velocidade = 0;
  float tempo = 0;
  float consumo =0;

  printf("Digite o tempo: ");
  scanf("%f", &tempo);
  printf("Digite a velocidade média: ");
  scanf("%f", &velocidade);

  distancia = velocidade * tempo;
  consumo = distancia/AUTONOMIA;

  printf("%.3f", consumo);

  return 0;
}

