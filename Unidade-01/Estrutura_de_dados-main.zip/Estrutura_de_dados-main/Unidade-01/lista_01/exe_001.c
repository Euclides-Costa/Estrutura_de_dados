
#include <stdio.h>

int main(void)
{
  /*
    s = sarário do vendedor
    t_v = total de vendas
    t_r = total a receber
  */
  char nome[20];
  float s = 0, t_v = 0, t_r = 0;
  
  printf("Digite o seu nome: ");
  scanf("%s", nome);
  printf("Digite o seu salário: ");
  scanf("%f", &s);
  printf("Digite o valor total das vendas: ");
  scanf("%f", &t_v);
  
  printf("%s\n", nome);
  printf("%f\n", s);
  printf("%f\n", t_v);

  t_r = s + (t_v * 0.15);
  printf("TOTAL = R$ %.2f", t_r);
  
  return 0;
}
